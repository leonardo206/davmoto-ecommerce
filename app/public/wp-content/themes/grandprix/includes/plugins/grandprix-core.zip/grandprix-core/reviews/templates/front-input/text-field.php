<div class="mkdf-comment-input-text">
	<label><?php esc_html_e( 'Comment', 'grandprix-core' ) ?></label>
	<textarea id="comment" name="comment" cols="45" rows="6" aria-required="true"></textarea>
</div>
