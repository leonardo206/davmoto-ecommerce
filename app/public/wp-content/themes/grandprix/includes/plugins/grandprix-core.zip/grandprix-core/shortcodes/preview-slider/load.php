<?php
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/preview-slider/functions.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/preview-slider/preview-slider.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/preview-slider/preview-slide.php';