<div itemprop="name" class="mkdf-pvli-title entry-title">
    <?php echo esc_attr(get_the_title()); ?>
</div>
