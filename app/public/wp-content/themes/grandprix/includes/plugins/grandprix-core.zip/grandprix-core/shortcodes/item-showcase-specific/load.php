<?php

include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/item-showcase-specific/functions.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/item-showcase-specific/item-showcase-specific.php';