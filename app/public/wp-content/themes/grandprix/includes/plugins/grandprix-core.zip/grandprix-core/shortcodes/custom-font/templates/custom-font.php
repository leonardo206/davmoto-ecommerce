<<?php echo grandprix_mikado_core_escape_title_tag( $title_tag ); ?> class="mkdf-custom-font-holder <?php echo esc_attr( $holder_classes ); ?>" <?php grandprix_mikado_inline_style( $holder_styles ); ?> <?php echo grandprix_mikado_get_inline_attrs( $holder_data ); ?>>
	<?php echo wp_kses_post( $title ); ?>
</<?php echo grandprix_mikado_core_escape_title_tag( $title_tag ); ?>>