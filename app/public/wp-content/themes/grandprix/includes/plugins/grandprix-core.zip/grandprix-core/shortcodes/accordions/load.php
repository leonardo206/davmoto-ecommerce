<?php

include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/accordions/functions.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/accordions/accordion.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/accordions/accordion-tab.php';