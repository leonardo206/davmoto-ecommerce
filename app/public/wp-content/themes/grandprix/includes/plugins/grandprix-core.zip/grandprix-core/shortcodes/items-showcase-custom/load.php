<?php

include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/items-showcase-custom/functions.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/items-showcase-custom/items-showcase-custom.php';