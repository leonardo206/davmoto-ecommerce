<div class="mkdf-reviews-list-info mkdf-reviews-count">
	<<?php echo grandprix_mikado_core_escape_title_tag( $title_tag ); ?> class="mkdf-reviews-summary">
        <span class="mkdf-reviews-number">
            <?php echo esc_html( $rating_number ); ?>
        </span>
		<span class="mkdf-reviews-label">
            <?php echo esc_html( $rating_label ); ?>
        </span>
	</<?php echo grandprix_mikado_core_escape_title_tag( $title_tag ); ?>>
</div>